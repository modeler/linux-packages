/* compile-time config file for the opencbm kernel module */

/* port access mode (ignored for 2.0.x kernels) */
#undef DIRECT_PORT_ACCESS
