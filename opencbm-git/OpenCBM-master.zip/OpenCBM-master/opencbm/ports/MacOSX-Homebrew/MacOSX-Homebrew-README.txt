
Homebrew - The missing package manager for OS X.

http://mxcl.github.com/homebrew/

https://github.com/mxcl/homebrew
https://github.com/mxcl/homebrew/tree/master/Library/Formula/


