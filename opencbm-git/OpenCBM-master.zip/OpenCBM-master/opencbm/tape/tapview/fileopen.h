/*
 *  CBM 1530/1531 tape routines.
 *  Copyright 2012 Arnd Menge, arnd(at)jonnz(dot)de
*/

void UpdateBitmapMetrics(void);
BOOL OpenFileDialog(HWND hWnd);
BOOL StartLoaderThread(void);
void RepaintPic(int ScrollPos);
