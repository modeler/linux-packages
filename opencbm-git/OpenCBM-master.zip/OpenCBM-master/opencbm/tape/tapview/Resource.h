#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDC_STATUSBAR                           100
#define IDC_PROGRESSBAR                         101
#define IDC_SCROLLBAR                           102
#define IDD_ABOUTBOX                            103
#define IDM_ABOUT                               104
#define IDM_EXIT                                105
#define IDC_TAPVIEW                             109
#define IDM_OPENCAPIMAGE                        120
#define IDM_SHOW_HALFWAVES                      122
#define IDM_FIRST_HALFWAVE_IN_DARK_GREEN        123
#define IDM_USE_2H_BUFFER                       40000
#define IDS_APP_TITLE                           40000
#define IDM_USE_5H_BUFFER                       40001
#define IDM_USE_1H_BUFFER                       40002
#define IDM_DOUBLE_SCREEN_HEIGHT                40003
#define IDM_DOUBLE_SCREEN_WIDTH                 40004
