#ifndef VERSION_H
#define VERSION_H

#define XU1541_VERSION_MAJOR        0x01
#define XU1541_VERSION_MINOR        0x18

#endif /* #ifndef VERSION_H */
