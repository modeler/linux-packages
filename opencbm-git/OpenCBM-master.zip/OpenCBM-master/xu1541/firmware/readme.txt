xu1541 firmware
---------------

This directory contains the xu1541 firmware.

Please visit http://www.harbaum.org/till/xu1541 for details.
